//
//  CustomCollectionViewCell.swift
//  Module2TableViewLogIn
//
//  Created by Vivek Patel on 24/04/23.
//

import UIKit

class CustomCollectionViewCell: UICollectionViewCell {
    
    
    @IBOutlet weak var image: UIImageView!

}
