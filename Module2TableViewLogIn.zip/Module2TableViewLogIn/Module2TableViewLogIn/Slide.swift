//
//  slide.swift
//  Module2TableViewLogIn
//
//  Created by Vivek Patel on 25/04/23.
//

import UIKit

class Slide: UIView {
    
    @IBOutlet weak var imageView: UIImageView!
    
    @IBOutlet weak var labelTitle: UILabel!
    @IBOutlet weak var labelDesc: UILabel!
    
    
    
   
    
}
