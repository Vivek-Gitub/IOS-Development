//
//  ViewController.swift
//  Module2TableViewLogIn
//
//  Created by Vivek Patel on 22/04/23.
//

import UIKit

class ViewController: UIViewController {

    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view.
    }


}

