//
//  CollectionTableViewCell.swift
//  Module2TableViewLogIn
//
//  Created by Vivek Patel on 24/04/23.
//

import UIKit

import WebKit


class CollectionTableViewCell: UITableViewCell {

    @IBOutlet weak var imageLabel: UILabel!
    
    @IBOutlet weak var webView: WKWebView!
    
    
}
