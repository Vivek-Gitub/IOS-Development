//
//  CustomTableViewCell.swift
//  Module2TableViewLogIn
//
//  Created by Vivek Patel on 22/04/23.
//

import UIKit

class CustomTableViewCell: UITableViewCell {

    // here inthis we drag all ement of the cell in table view
    @IBOutlet weak var imagelabels: UILabel!
    @IBOutlet weak var imageIcons: UIImageView!
    
    @IBOutlet weak var iDNumber: UILabel!
    
}
