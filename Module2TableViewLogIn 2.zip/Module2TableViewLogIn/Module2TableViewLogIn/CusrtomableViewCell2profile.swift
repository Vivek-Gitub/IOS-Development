//
//  CusrtomableViewCell2profile.swift
//  Module2TableViewLogIn
//
//  Created by Vivek Patel on 27/04/23.
//

import UIKit

class CusrtomableViewCell2profile: UITableViewCell {

    @IBOutlet weak var label2profile: UILabel!
    
    @IBOutlet weak var textField2profile: UITextField!
    
}
