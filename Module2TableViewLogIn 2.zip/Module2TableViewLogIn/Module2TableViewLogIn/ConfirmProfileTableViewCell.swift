//
//  ConfirmProfileTableViewCell.swift
//  Module2TableViewLogIn
//
//  Created by Vivek Patel on 27/04/23.
//

import UIKit

class ConfirmProfileTableViewCell: UITableViewCell {
    
    @IBOutlet weak var confirmprofileTabel: UILabel!
    
    @IBOutlet weak var confirmProfileTextField: UITextField!
}
